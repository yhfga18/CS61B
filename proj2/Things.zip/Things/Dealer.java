package Things;

import db.Database;

/**
 * Created by hideyoshitakahashi on 2/24/17.
 */
public class Dealer {

    public static String dealCreateTable(String tableName, String[] columnTitles){

        Table newTable = new Table(tableName, columnTitles);
        Database.database.put(tableName, newTable);
        /*
        newTable.addNameRow(tableName);
        newTable.addItemRow(tableColumns);
        */
        return "";
    }

    public static String dealStore(String tableName){
        Table t = Database.database.get(tableName);
        // make a file for the table somehow.
        return "dealStore!!, Table t = " + tableName;
    }

    public static String dealLoad(String fileName){
        Table newTable = new Table(fileName);
        Database.database.put(fileName, newTable);
        // load the file somehow
        return "dealStore!!, Table t = " + fileName;
    }

    public static String dealDrop(String tableName){
        Database.database.remove(tableName);
        return "";
    }

    public static String dealInsert(String tableName, String[] values){
        if (Database.database.containsKey(tableName)) {
            Table t = Database.database.get(tableName);
            t.addRowLast(values);
        }
        return "";
    }
    public static String dealPrint(String tableName){
        if (Database.database.containsKey(tableName)) {
            Table t = Database.database.get(tableName);
            return t.toString();
        }
        // make a string to return. ここちゃんとできてない
        return "There isn't such the table";
    }
    public static String dealSelect(String columnTitle, String tableName, String condition){
        Table originalTable = Database.database.get(columnTitle);
        Table anonTable = new Table();
           // anonTable.addRowLast();

        // ここでわかるのが、それぞれのrowがtoStringを持ってた方がいい、ということ

        // make a string to return.
        return "dealSelect!!, tableName = " + tableName;
    }
}
