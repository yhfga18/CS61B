package Things;
import java.util.List;
import java.util.LinkedList;
import java.util.ArrayList;
import java.util.Iterator;


public class Table<T> {

    private String name;
    private ArrayList<LinkedList<T>> zeroColumn;
    private LinkedList<String> zeroRow;
    private int columnCap;

    public Table() {
        this("anonymous", new String[0]); //this("", new String[0]) ?
    }

    public Table(String name) {
        this(name, new String[0]);
    }

    public Table(String name, String[] columnTitles) {
        this.name = name;
        this.zeroColumn = new ArrayList<LinkedList<T>>(10);
        this.columnCap = 10;
        this.zeroRow = new LinkedList<String>();
        for (String s : columnTitles) {
            zeroRow.add(s);
        }
        // size() method でelement(row)の個数はわかる！
    }

    public boolean isFull(){
        return this.zeroColumn.size() >= this.columnCap;
    }

    // trimToSize() method でarrayListのcontainer減らせる

    public void addRowLast(String[] strs) {
        LinkedList newRow = new LinkedList<String>();
        for (String elem : strs) {
            newRow.add(elem);
        }
        if (this.isFull()) {
            this.columnCap = this.columnCap * 2;
            this.zeroColumn.ensureCapacity(this.columnCap);
        }
        this.zeroColumn.add(newRow);
    }

    public String get(){
        return "";
    }

    public String toString(){
        for (LinkedList elem : this.zeroColumn) {
            for (Object s : elem) {
                System.out.print(s + ", ");
            }
            System.out.println();
        }
        return ""; // ここ議論に反する
    }

}















   /*
    private class Row {
        private List row;
        private List somePointer;

        public Row(){
            this.row = new LinkedList<T>(null);
            this.somePointer = null;
        }

        // column specialized methods come here
    }

    private class Column {
        private List column;
        private List somePointer;

        public Column(){
            this.column = new ArrayList<T>(null);
            this.somePointer = null;

        }
        // column specialized methods come here
    }

    */





