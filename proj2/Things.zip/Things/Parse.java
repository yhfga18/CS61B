package Things;

import java.util.regex.Pattern;
import java.util.regex.Matcher;

import java.util.StringJoiner;

import db.Database;

public class Parse {
    // Various common constructs, simplifies parsing.
    private static final String REST  = "\\s*(.*)\\s*",
                                COMMA = "\\s*,\\s*",
                                AND   = "\\s+and\\s+";

    // Stage 1 syntax, contains the command name.
    private static final Pattern CREATE_CMD = Pattern.compile("create table " + REST),
                                 LOAD_CMD   = Pattern.compile("load " + REST),
                                 STORE_CMD  = Pattern.compile("store " + REST),
                                 DROP_CMD   = Pattern.compile("drop table " + REST),
                                 INSERT_CMD = Pattern.compile("insert into " + REST),
                                 PRINT_CMD  = Pattern.compile("print " + REST),
                                 SELECT_CMD = Pattern.compile("select " + REST);

    // Stage 2 syntax, contains the clauses of commands.
    private static final Pattern CREATE_NEW  = Pattern.compile("(\\S+)\\s+\\((\\S+\\s+\\S+\\s*" +
                                               "(?:,\\s*\\S+\\s+\\S+\\s*)*)\\)"),
                                 SELECT_CLS  = Pattern.compile("([^,]+?(?:,[^,]+?)*)\\s+from\\s+" +
                                               "(\\S+\\s*(?:,\\s*\\S+\\s*)*)(?:\\s+where\\s+" +
                                               "([\\w\\s+\\-*/'<>=!]+?(?:\\s+and\\s+" +
                                               "[\\w\\s+\\-*/'<>=!]+?)*))?"),
                                 CREATE_SEL  = Pattern.compile("(\\S+)\\s+as select\\s+" +
                                                   SELECT_CLS.pattern()),
                                 INSERT_CLS  = Pattern.compile("(\\S+)\\s+values\\s+(.+?" +
                                               "\\s*(?:,\\s*.+?\\s*)*)");

    /*create table が patternで、それをpattern.compileしたものは
    Javaがプログラムの中で使うための、Java用のpatternだと思えばいいらしい
    一応俺らから見て、CREAT_CMD は pattern. (an object)
    上のCREATE_CMDとかLOAD_CMDとかを pattern object と呼ぶそうです

     Matcher class は存在するけど、それはPattern classで
     定義されているmatcher メソッドを使って生成するらしい

     次は、上で生成したパターンオブジェクトがターゲットとなる文字列を対象に
     マッチしているかどうかを調べるためにマッチャを使う
    */

    // main method was here now copied/pasted at the end of the program

    /* mactherの使い方：
    （1）
    Matcher m = p.matcher(str)
    ここで str は対象となるString, p はJava用のpattern. patternのmethodであるmatcherをつかって
    Matcher object を生成した。

    （２）
    たぶん上のmにたいして.matchesで、実際にmatchしてるかどうかを調べている。

     */

    public static String eval(String query) {
        Matcher m;
        if ((m = CREATE_CMD.matcher(query)).matches()) {
            return createTable(m.group(1));
        } else if ((m = LOAD_CMD.matcher(query)).matches()) {
            System.out.println("group 1 ____ : " + m.group(1)); // T1
            return loadTable(m.group(1));
        } else if ((m = STORE_CMD.matcher(query)).matches()) {
            return storeTable(m.group(1));
        } else if ((m = DROP_CMD.matcher(query)).matches()) {
            return dropTable(m.group(1));
        } else if ((m = INSERT_CMD.matcher(query)).matches()) {
            return insertRow(m.group(1));
        } else if ((m = PRINT_CMD.matcher(query)).matches()) {
            return printTable(m.group(1));
        } else if ((m = SELECT_CMD.matcher(query)).matches()) {
            return select(m.group(1));
        } else {
            // System.err.printf("Malformed query: %s\n", query);
            return "Malformed!!!";
        }
    }

    private static String createTable(String expr) {
        // expr = T1 (x int, y int), for create table T1 (x int, y int)
        Matcher m;
        if ((m = CREATE_NEW.matcher(expr)).matches()) { // new table を作る
                    //System.out.println("in createTable method, ");
                    //System.out.println("group1 is : " + m.group(1)); // T1
                    //System.out.println("group2 is : " + m.group(2));
                    //System.out.println(m.group(2).split(COMMA));

            // *** createNewTable(m.group(1), m.group(2).split(COMMA));
            String Tname = m.group(1);
            String[] Tcolumns = m.group(2).split(COMMA);
            return Dealer.dealCreateTable(Tname, Tcolumns);

        } else if ((m = CREATE_SEL.matcher(expr)).matches()) { // selectを含む
            // *** createSelectedTable(m.group(1), m.group(2), m.group(3), m.group(4));
                    //System.out.println(m.group(1));
                    //System.out.println(m.group(2));
                    //return Dealer.dealCreateSelect();

        } else {
            System.err.printf("Malformed create: %s\n", expr);
        }
        return expr;
    }
    /* Printing stuffs info
    for "" create table T1 (x int, y int) "" ,
    System.out.println("in createTable method, ");
    System.out.println("group1 is : " + m.group(1)); // group1 is T1 (table's name)
    System.out.println("group2 is : " + m.group(2)); // x int, y int (かっこの中)
    System.out.println(m.group(2).split(COMMA)); // location info

     */


    /* createTable
    ここでは general な意味でcreate table に対応している。この中で、そのcreate tableの restが
        (1) select を含む → createSelectedTable();
        (2) select を含まない → createNewTable();
    に飛ばすか決めて飛ばした先でそれぞれにappropriateな操作を施す。
    */

    private static String createNewTable(String name, String[] cols) {
        // name = table's name,
        // cols = rest of the input
        StringJoiner joiner = new StringJoiner(", "); // package String Joiner
        for (int i = 0; i < cols.length-1; i++) {
            joiner.add(cols[i]);
        }

        String colSentence = joiner.toString() + " and " + cols[cols.length-1];
        System.out.printf("You are trying to create a table named %s with the columns %s\n", name, colSentence);
        // System.out.println(cols[0]); // x int
        // System.out.println(cols[1]); // y int

        // うえのStringJoiner joiner から "You are tring..." まで全部適当。動くように適当に
        // 与えられてるだけ。以下からメインのコード

        // Things.Dealer に飛ばす
        //String result = Things.Dealer.dealCreateTable(name, cols);

        return name;

        /* format:
        create table <table name> (<column0 name> <type0>, <column1 name> <type1>, ...)
         つまり上のcolにはcolumn name と type が入りまくってる。
         */



    }


    private static String createSelectedTable(String name, String exprs, String tables, String conds) {
        System.out.printf("You are trying to create a table named %s by selecting these expressions:" +
                " '%s' from the join of these tables: '%s', filtered by these conditions: '%s'\n", name, exprs, tables, conds);
        return name;
    }

    private static String loadTable(String fileName) {
        // System.out.printf("You are trying to load the table named %s\n", name);

        // load a file called name, somehow.
        System.out.println("LOAD fileName is: " + fileName);
        return Dealer.dealLoad(fileName);
    }

    private static String storeTable(String name) {
        System.out.printf("You are trying to store the table named %s\n", name);
        return Dealer.dealStore(name);
        // パソコンにどうにかして入れ戻す (String file にする iteration でやればいい)

    }

    private static String dropTable(String name) {
        System.out.printf("You are trying to drop the table named %s\n", name);
        return Dealer.dealDrop(name);

    }

    private static String insertRow(String expr) {
        /*
        original = insert into tname values (1,2,3,4)
        expr = tname values (1,2,3,4)
         */
        Matcher m = INSERT_CLS.matcher(expr);
        if (!m.matches()) {
            System.err.printf("Malformed insert: %s\n", expr);
            return null;
        } else {
            System.out.printf("You are trying to insert the row \"%s\" into the table %s\n", m.group(2), m.group(1));
            //System.out.println("m.group1, mgroup2 are ...... : " + m.group(1) + " and " + m.group(2));
            String tableName = m.group(1);
            String[] values = m.group(2).split(COMMA);
            return Dealer.dealInsert(tableName, values);
        }
    }

    private static String printTable(String name) {
        System.out.printf("You are trying to print the table named %s\n", name);
        return Dealer.dealPrint(name);
    }

    private static String select(String expr) {
        Matcher m = SELECT_CLS.matcher(expr);
        if (!m.matches()) {
            System.err.printf("Malformed select: %s\n", expr);
        }
        String columnTitle = m.group(1);
        String tableName = m.group(2);
        String condition = m.group(3);
        return Dealer.dealSelect(columnTitle, tableName, condition);

        // System.out.println(m.group(1) + "-2-" + m.group(2) + m.group(3));
        // select x from T1 where x > 2 をした時は、
        // group1 = x つまり columnのtitle
        // group2 = T1 つまり table の名前
        // group3 = x > 2 つまり whereの中
    }

    private static String select(String exprs, String tables, String conds) {
        System.out.printf("You are trying to select these expressions:" +
                " '%s' from the join of these tables: '%s', filtered by these conditions: '%s'\n", exprs, tables, conds);
        return exprs;
    }
}





//    public static void main(String[] args) {
//        if (args.length != 1) {
//            System.err.println("Expected a single query argument");
//            return;
//        }
//
//        eval(args[0]);
//    }




//    public static String evalCreateTable(String rest){
//        /*
//        rest: <table name> (<column0 name> <type0>, <column1 name> <type1>, ...)
//        or
//        rest: <table name> as <select clause> // SELECT!!
//         */
//
//        return rest;
//    }
//
//    public static String evalLoad(String rest){
//        /*
//        rest:
//         */
//        return "evaluating rest of load, which is ... " + rest + "!!";
//    }
//    public static String evalStore(String rest){
//        return "evalStore!";
//    }
//    public static String evalDrop(String rest){
//        return "evalDrop!";
//    }
//    public static String evalInsertRow(String rest){
//        return "evalRow!";
//    }
//    public static String evalPrint(String rest){
//        return "evalPrint!";
//    }
//    public static String evalSelect(String rest){
//        return "evalSelect!";
//    }





